#ifndef MINIMOSCUADRADOSFIB_HPP
#define MINIMOSCUADRADOSFIB_HPP 

bool minimosCuadradosFib();

#endif