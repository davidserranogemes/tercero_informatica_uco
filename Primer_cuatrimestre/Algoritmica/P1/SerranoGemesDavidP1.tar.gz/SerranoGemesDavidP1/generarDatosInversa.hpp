#ifndef GENERARDATOSINVERSA_HPP
#define GENERARDATOSINVERSA_HPP

#include <iostream>
#include <cstdlib>
#include <locale>
#include <list>
#include <string>
#include <vector>


void generarDatosInversa(int min, int max, int inc);


#endif