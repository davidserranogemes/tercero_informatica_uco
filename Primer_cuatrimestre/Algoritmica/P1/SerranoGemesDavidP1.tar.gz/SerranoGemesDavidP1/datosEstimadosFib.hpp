#ifndef DATOSESTIMADOSFIB_HPP
#define DATOSESTIMADOSFIB_HPP 

bool datosEstimadosFib();

#endif