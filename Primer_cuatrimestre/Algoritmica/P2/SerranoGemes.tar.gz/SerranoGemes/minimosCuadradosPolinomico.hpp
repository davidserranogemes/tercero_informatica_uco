#ifndef MINIMOSCUADRADOSPOLINOMICO_HPP
#define MINIMOSCUADRADOSPOLINOMICO_HPP


bool minimosCuadradosPolinomico();

#endif
