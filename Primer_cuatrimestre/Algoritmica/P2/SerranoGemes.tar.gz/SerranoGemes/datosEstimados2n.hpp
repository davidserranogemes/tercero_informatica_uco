#ifndef DATOSESTIMADOS2N_HPP
#define DATOSESTIMADOS2N_HPP 

bool datosEstimados2n();

#endif