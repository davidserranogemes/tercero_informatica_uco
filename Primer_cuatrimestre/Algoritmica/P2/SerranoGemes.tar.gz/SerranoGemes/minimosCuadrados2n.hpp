#ifndef MINIMOSCUADRADOS2N_HPP
#define MINIMOSCUADRADOS2N_HPP 

bool minimosCuadrados2n();

#endif