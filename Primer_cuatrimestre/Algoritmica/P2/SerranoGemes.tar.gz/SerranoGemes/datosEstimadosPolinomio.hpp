#ifndef DATOSESTIMADOSPOLINOMIO_HPP
#define DATOSESTIMADOSPOLINOMIO_HPP

bool datosEstimadosPolinomio();


#endif