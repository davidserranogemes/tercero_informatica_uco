#ifndef DATOSFIBONACI_HPP
#define DATOSFIBONACI_HPP

long double fibonacci(int n);

#endif
