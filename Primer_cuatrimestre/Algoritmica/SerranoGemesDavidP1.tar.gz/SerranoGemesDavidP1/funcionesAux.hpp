#ifndef FUNCIONESAUX_HPP
#define FUNCIONESAUX_HPP
#include <string>

bool checkCadenaIsDigit(std::string cadena);
bool checkCadenaIsDigit(char *cadena);

#endif
