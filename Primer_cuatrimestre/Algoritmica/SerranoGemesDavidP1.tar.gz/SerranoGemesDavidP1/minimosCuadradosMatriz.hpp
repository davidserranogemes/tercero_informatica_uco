#ifndef MINIMOSCUADRADOSMATRIZ_HPP
#define MINIMOSCUADRADOSMATRIZ_HPP


bool minimosCuadradosMatriz();

#endif
