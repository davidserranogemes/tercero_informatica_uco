from empresa.models import Empresa
from django.contrib.auth.forms import UserCreationForm
from django import forms





#Usercreationform hashea la pass directamente

class EmpresaResgisterForm(UserCreationForm):
	class Meta:
		model = Empresa
		fields=('username','descripcion','telefono','email','nombre')

class EmpresaLoginForm(forms.Form):
	username = forms.CharField()
	password = forms.CharField(widget=forms.PasswordInput, label="Password")