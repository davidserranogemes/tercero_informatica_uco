from django.shortcuts import render


def index(request):
	return render(request,'djangoPW/index.html')


def buscar_zona(request):
	