from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from .models import Empresa
from cursos.models import Curso
from practicas.models import Practica
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.core.urlresolvers import reverse_lazy
from empresa.form import EmpresaResgisterForm, EmpresaLoginForm
from django.views.generic.detail import DetailView
from django.contrib.auth.decorators import login_required


# Create your views here.

def Registro(request):
	if request.user.is_authenticated():
		return HttpResponse("Ya estas registrado")
	else:
		if request.method == 'POST':
			form = EmpresaResgisterForm(request.POST,request.FILES)
			if form.is_valid():
				form.save()
				return redirect("/empresa/agregado")
		else:
			form = EmpresaResgisterForm()
		context = {'form':form}
		return render(request,'empresa/RegistroEmpresa.html',context) 

def Agregado(request):
	return render(request, 'empresa/Agregado.html')

def Login(request):
	if request.user.is_authenticated():
		return redirect("/empresa/already_loged")
	else:
		if request.method == 'POST':
			username = request.POST['username']
			password = request.POST['password']
			user = authenticate(username=username, password=password)
			if user is not None:
				login(request, user)
				return redirect("/empresa/mi_empresa")
			else:
				return redirect("/empresa/login")
		else:
			form = EmpresaLoginForm()
		context = {'form':form}
		return render(request,'empresa/LoginEmpresa.html',context)

def Logout(request):
	if request.user.is_authenticated():
		logout(request)
		return render(request, "empresa/Logout.html")
	else:
		return redirect("/empresa/not_loged")

def Already_loged(request):
	return render(request,"empresa/Already_loged.html")
def Not_loged(request):
	return render(request,"empresa/Not_loged.html")

@login_required()
def Mi_empresa(request):
	empresa = get_object_or_404(Empresa, username=request.user.get_username())
	mis_cursos = Curso.objects.filter(empresa=empresa)
	mis_practicas = Practica.objects.filter(empresa=empresa)
	context={"empresa":empresa,"mis_cursos":mis_cursos, "mis_practicas":mis_practicas}
	return render(request,"empresa/Mi_empresa.html",context)


def Detalle_empresa(request,pk):
	empresa=get_object_or_404(Empresa, pk=pk)
	lista_cursos=Curso.objects.filter(empresa=empresa)
	lista_practicas=Practica.objects.filter(empresa=empresa)
	context={'empresa':empresa ,'lista_cursos':lista_cursos, 'lista_practicas':lista_practicas}
	return render(request,"empresa/Detalle_empresa_publico.html",context)