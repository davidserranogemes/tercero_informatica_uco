#include <cmath>

#include <iostream>
#include "funciones.hpp"
#include "Region.hpp"

struct Adyacentes{
	float dist;
	bool active;
};

int tablaCodigoUniforme(int valorLBP);


int computeLBP(const char a, const char b, const char c, const char d, const char e, const char f, const char g, const char h, const char i , bool uniform){
	int valorLBP=0;
	int vectorLBP[8];
	int valorLBPUniformed=0;

	for(int i=0;i<8;i++){
		vectorLBP[i]=0;
	}
	if(a>=i){
		vectorLBP[7]=1;
	}
	if(b>=i){
		vectorLBP[6]=1;	
	}
	if(c>=i){
		vectorLBP[5]=1;
	}
	if(d>=i){
		vectorLBP[4]=1;
	}
	if(e>=i){
		vectorLBP[3]=1;
	}
	if(f>=i){
		vectorLBP[2]=1;
	}
	if(g>=i){
		vectorLBP[1]=1;
	}
	if(h>=i){
		vectorLBP[0]=1;
	}

	for(int i=0;i<8;i++){
		if(vectorLBP[i]){
			valorLBP=valorLBP+pow(2,i);
		}
	}

	if(uniform){
		valorLBPUniformed=tablaCodigoUniforme(valorLBP);
		//std::cout<<valorLBPUniformed<<std::endl;
		return valorLBPUniformed;
	}else{
//		std::cout<<valorLBP<<std::endl;
		return valorLBP;
	}
}



cv::Mat computeLBPImage(const cv::Mat& img, bool uniform){
	cv::Mat LBPImage(img.rows, img.cols, CV_8UC1);
	for(int j=0;j<LBPImage.cols;j++){
		for(int k=0;k<LBPImage.rows;k++){
			LBPImage.at<uchar>(k,j)=0;
		}
	}
	for(int j=1;j<LBPImage.cols-1;j++){
		for(int k=1;k<LBPImage.rows-1;k++){
			LBPImage.at<uchar>(k,j)=computeLBP(img.at<uchar>(k-1,j-1),(int)img.at<uchar>(k-1,j),(int)img.at<uchar>(k,j+1),(int)img.at<uchar>(k,j+1),(int)img.at<uchar>(k+1,j+1),(int)img.at<uchar>(k+1,j),(int)img.at<uchar>(k+1,j-1),(int)img.at<uchar>(k,j-1),(int)img.at<uchar>(k,j),uniform);
//			LBPImage.at<CV_8UC1>(k,j)=computeLBP(img.at<CV_8UC1>(k-1,j-1),img.at<CV_8UC1>(k-1,j),img.at<CV_8UC1>(k,j+1),img.at<CV_8UC1>(k,j+1),img.at<CV_8UC1>(k+1,j+1),img.at<CV_8UC1>(k+1,j),img.at<CV_8UC1>(k+1,j-1),img.at<CV_8UC1r>(k,j-1),img.at<CV_8UC1>(k,j),uniform);

		}
	}


	return LBPImage;
}


cv::Mat computeLBPHist(const cv::Mat& lbpImg, const cv::Rect& roi, const cv::Mat mask, bool normalize,bool LBPU){	//Prepara la imagen a tratar
	cv::Mat imgMask;

	//lbpImg.copyTo(imgMask,mask);

	//cv::Mat imgPrepared(imgMask,roi);
	/*std::cout<<"Failure "<<"x: "<<roi.x<<" y: "<<roi.y<<" w: "<<roi.width<<" h: "<<roi.height<<std::endl;
	std::cout<<"Failure "<<"rows: "<<lbpImg.rows<<" cols: "<<lbpImg.cols<<std::endl<<std::endl;;

	if(roi.x >= 0 && roi.y >= 0 && roi.width + roi.x <= lbpImg.cols && roi.height + roi.y <= lbpImg.rows){
		std::cout<<roi.x<<" >= 0 && "<<roi.y<<" >= 0 && "<<roi.width + roi.x<<" < "<<lbpImg.cols<<" && "<<roi.height + roi.y<<" < "<<lbpImg.rows<<std::endl;
		std::cout<<"Works"<<std::endl;
		
	}else{
		std::cout<<roi.x<<" >= 0 && "<<roi.y<<" >= 0 && "<<roi.width + roi.x<<" < "<<lbpImg.cols<<" && "<<roi.height + roi.y<<" < "<<lbpImg.rows<<std::endl;
		std::cout<<"Dont work"<<std::endl;
	}
	*/
	cv::Mat imgPrepared(lbpImg,roi);
	//Ahora recorremos la imagen
	cv::Mat hist(1, 256, CV_32F);
	bool uniformed=true;

	for(int j=0;j<256;j++){
		hist.at<float>(j)=0;
	}
	int razon=0;
	float accumm=0;
	for(int j=0;j<imgPrepared.cols;j++){
		for(int k=0;k<imgPrepared.rows;k++){
			//std::cout<<(int)imgPrepared.at<uchar>(k,j)<<"/";
			hist.at<float>((int)imgPrepared.at<uchar>(k,j))=hist.at<float>((int)imgPrepared.at<uchar>(k,j))+1;
			//std::cout<<hist.at<float>((int)imgPrepared.at<uchar>(k,j))<<" ";
			razon++;

		}
	}
	//std::cout<<std::endl;

	//Compruebo si el LVP Estaba o no unificado
/*
	for(int j=59;j<256;j++){
		//std::cout<<"["<<hist.at<float>(j)<<"]";

		if(hist.at<float>(j)>0){
			uniformed=false;
		}
	}
*/
	if(LBPU){
		cv::Mat histUniformed(1, 59, CV_32F);
		for(int j=0;j<59;j++){
			histUniformed.at<float>(j)=hist.at<float>(j);
		}

		if(normalize){
			for(int j=0;j<59;j++){
			
			//	std::cout<<"["<<histUniformed.at<float>(j)<<"]";

				histUniformed.at<float>(j)=histUniformed.at<float>(j)/razon;
				accumm=accumm+histUniformed.at<float>(j);
			}
		//				std::cout<<std::endl;
			//	std::cout<<accumm<<std::endl;
		}
//		std::cout<<"Uniform"<<std::endl;
		return histUniformed;


	}else{

		//normalizar
		if(normalize){
			for(int j=0;j<256;j++){
			//	std::cout<<"["<<hist.at<float>(j)<<"]";

				hist.at<float>(j)=hist.at<float>(j)/razon;
				accumm=accumm+hist.at<float>(j);
			}
			
			//std::cout<<accumm<<std::endl;

		}
//std::cout<<"Not Uniform"<<std::endl;
		return hist;

	}

}


float computeHistogramDistance(const cv::Mat& h1, const cv::Mat& h2){
	double result=cv::compareHist(h1,h2,CV_COMP_CHISQR);
	return result;
}



std::vector<Region> splitRegion(const Region& r){
	std::vector<Region> splitted;
	
	cv::Rect insert;
	cv::Rect rectAux=r.rects()[0];
	int rectsX,rectsWid,rectsY,rectsHei;

	rectsX=rectAux.x;
	rectsY=rectAux.y;
	rectsWid=rectAux.width;
	rectsHei=rectAux.height;

	//rectsWid=rectAux.height;
	//rectsHei=rectAux.width;

//	std::cout<<"x: "<<rectsX<<" y: "<<rectsY<<" width: "<<rectsWid<<" height: "<<rectsHei<<std::endl;
	insert.x=rectsX;
	insert.y=rectsY;
	insert.width=rectsWid/2;
	insert.height=rectsHei/2;
	cv::Mat mask;
	Region reg1(insert,mask);
	splitted.push_back(reg1);
/*	
	std::cout<<"X: "<<insert.x<<" Y: "<<insert.y<<std::endl;
	std::cout<<"width: "<<insert.width<<" height: "<<insert.height<<std::endl;
	std::cout<<std::endl;
*/	
	insert.x=rectsX;
	insert.y=(rectsHei/2)+rectsY;
	insert.width=rectsWid/2;//
	insert.height=rectsHei/2;//
	Region reg2(insert,mask);
	splitted.push_back(reg2);

/*
	std::cout<<"X: "<<insert.x<<" Y: "<<insert.y<<std::endl;
	std::cout<<"width: "<<insert.width<<" height: "<<insert.height<<std::endl;
	std::cout<<std::endl;
*/	
	insert.x=(rectsWid/2)+rectsX;
	insert.y=rectsY;
	insert.width=rectsWid/2;
	insert.height=rectsHei/2;
	Region reg3(insert,mask);
	splitted.push_back(reg3);
/*
	std::cout<<"X: "<<insert.x<<" Y: "<<insert.y<<std::endl;
	std::cout<<"width: "<<insert.width<<" height: "<<insert.height<<std::endl;
	std::cout<<std::endl;
*/
	insert.x=(rectsWid/2)+rectsX;
	insert.y=(rectsHei/2)+rectsY;
	insert.width=rectsWid/2;
	insert.height=rectsHei/2;
	Region reg4(insert,mask);
	splitted.push_back(reg4);	
/*
	std::cout<<"X: "<<insert.x<<" Y: "<<insert.y<<std::endl;
	std::cout<<"width: "<<insert.width<<" height: "<<insert.height<<std::endl;
	std::cout<<std::endl;
*/	
	return splitted;
}


float computeSplitCoeff(const std::vector<Region>& rs){
	float ratio;
	float dist;
	float max;
	float min;
	dist=computeHistogramDistance(rs[0].hist(),rs[1].hist());

	max=dist;
	min=dist;
	for(int i=0;i<3;i++){
		for(int j=i+1;j<4;j++){
			dist=computeHistogramDistance(rs[i].hist(),rs[j].hist());
			if(dist>max){
				max=dist;
			}else{
				if(dist<min){
					min=dist;
				}
			}
		//std::cout<<"I: "<<i<<" J: "<<j<<"Max: "<<max<<" Min: "<<min<<" dist: "<<dist<<std::endl;

		}
	}
	ratio=max/min;
	return ratio;
}


float computeMICoeff(const Region& r1, const Region& r2){
	float dist=computeHistogramDistance(r1.hist(),r2.hist());

	if(r1.size()<r2.size()){
		return r1.size()*dist;
	}else{
		return r2.size()*dist;
	}
}


float findNextRegionsToMerge (const std::vector<Region>& regions, int& r1, int& r2){
	float minDist=9999999999;
	float auxDist;
	//std::cout<<"Inicia la comparacion de zonas, para intentar hacer merge, DEPURACION, para no volverme loco"<<std::endl;
	for(int i=0;i<regions.size();i++){
		for(int j=0;j<regions.size();j++){
			auxDist=computeMICoeff(regions[i],regions[j]);
			if(auxDist<minDist){
				r1=i;
				r2=j;
			}
		}
	}
	return minDist;
}

void fillRegion(const Region& r, cv::Mat &img,int valueEtiqueta){
	std::vector<cv::Rect> auxRects=r.rects();
	int x,y,h,w;
	for(int i=0;i<auxRects.size();i++){
		x=auxRects[i].x;
		y=auxRects[i].y;
		h=auxRects[i].height;
		w=auxRects[i].width;
		//std::cout<<"x: "<<x<<" y: "<<y<<" w: "<<w<<" h: "<<h<<" Etiqueta:"<<valueEtiqueta<<std::endl;
		for(int j=x;j<x+w;j++){
			for(int k=y;k<y+h;k++){
				//std::cout<<"j: "<<j<<" k: "<<k<<"Ancho: "<<x+w<<" Alto: "<<y+h<<" Etiqueta:"<<valueEtiqueta<<std::endl;
				img.at<uchar>(k,j)=valueEtiqueta;
			}
		}
	}
}


cv::Mat generatelSegmentedImage(const cv::Size& imageSize, const std::vector<Region>& regs){
	cv::Mat segmentedImage(imageSize,CV_8UC1);//No se puede usar CV_16I, CV_16U falla dejando la mitad de la pantalla en negro, provisionalmente uso CV_8UC1

	for(int i=0;i<regs.size();i++){
		//std::cout<<"I: "<<i<<std::endl;
		fillRegion(regs[i],segmentedImage,(i*3+7)%255+1);//Posible soluciona no tener mas de 255 etiquetas, evita que se pongan al final varias etiquetas con el mismo valor
		//fillRegion(regs[i],segmentedImage,i+1;
	}
	return segmentedImage;
}


cv::Mat getBorders (const cv::Mat segImg){
//	std::cout<<"rows: "<<segImg.rows<<" cols: "<<segImg.cols<<std::endl;
	cv::Mat borderImg(segImg.rows,segImg.cols,CV_8UC1);

	for(int j=1;j<borderImg.cols-1;j++){
		for(int k=1;k<borderImg.rows-1;k++){
//			std::cout<<"j:"<<j<<" k: "<<k<<std::endl;
			if(segImg.at<uchar>(k,j)!=segImg.at<uchar>(k+1,j+1) or segImg.at<uchar>(k,j)!=segImg.at<uchar>(k+1,j) or segImg.at<uchar>(k,j)!=segImg.at<uchar>(k+1,j-1) or segImg.at<uchar>(k,j)!=segImg.at<uchar>(k,j+1) or segImg.at<uchar>(k,j)!=segImg.at<uchar>(k,j-1) or segImg.at<uchar>(k,j)!=segImg.at<uchar>(k-1,j+1) or segImg.at<uchar>(k,j)!=segImg.at<uchar>(k-1,j) or segImg.at<uchar>(k,j)!=segImg.at<uchar>(k-1,j-1)){
				//Es frontera
				borderImg.at<uchar>(k,j)=255;
			}else{
				borderImg.at<uchar>(k,j)=0;
			}
		}
	}

	return borderImg;
}


void split(const cv::Mat& lbpImg, float sTh, float minSize, std::vector<Region>& regions, bool LBPU){
	std::vector<Region> pila;
	cv::Rect rectAux(0,0,lbpImg.cols,lbpImg.rows);
	cv::Mat hist(1,256,CV_8UC1);
	Region regAux(rectAux,hist);
	pila.push_back(regAux);

	float coefSplit;
	cv::Mat auxMat;

	cv::Mat hist1, hist2, hist3, hist4;
	cv::Mat lbp;
	cv::Mat mask;

	cv::Mat border;
	std::vector<Region> auxRegVec;
	lbp=computeLBPImage(lbpImg,LBPU);
	//cv::imshow("LBP",lbp);
	//cv::waitKey(0);
	do{

		auxRegVec=splitRegion(pila.back());

		hist1=computeLBPHist(lbp,auxRegVec[0].rects()[0],mask,true,LBPU);
	//	std::cout<<"Failure"<<"x: "<<auxRegVec[0].rects()[0].x<<" y: "<<auxRegVec[0].rects()[0].y<<" w: "<<auxRegVec[0].rects()[0].width<<" h: "<<auxRegVec[0].rects()[0].height<<std::endl;
		auxRegVec[0].setHist(hist1);
		hist2=computeLBPHist(lbp,auxRegVec[1].rects()[0],mask,true,LBPU);
		auxRegVec[1].setHist(hist2);
		hist3=computeLBPHist(lbp,auxRegVec[2].rects()[0],mask,true,LBPU);
		auxRegVec[2].setHist(hist3);
		hist4=computeLBPHist(lbp,auxRegVec[3].rects()[0],mask,true,LBPU);
		auxRegVec[3].setHist(hist4);


		coefSplit=computeSplitCoeff(auxRegVec);
	//	std::cout<<"Coef: "<<coefSplit<<"   -------   "<<" sTh: "<<sTh<<std::endl;
		if(coefSplit>sTh){
			//Divido
		//	std::cout<<"No es homogenena"<<std::endl;
			if(pila.back().size()>minSize){
				//std::cout<<"tam: "<<pila.back().size()<<std::endl;
				pila.pop_back();

				for(int i=0;i<auxRegVec.size();i++){
					pila.push_back(auxRegVec[i]);
				}
				auxRegVec.clear();
			}else{
				//std::cout<<"Tamanio minimo alcanzado."<<std::endl;
				regions.push_back(pila.back());
				pila.pop_back();


			}
		}else{
			//Es Homogeneo
		//	std::cout<<"Es homogenena"<<std::endl;
			regions.push_back(pila.back());
			pila.pop_back();

		}
	//	std::cout<<"Pila por calcular: "<<pila.size()<<"   Pila homogenena: "<<regions.size()<<std::endl;
	}while(!pila.empty());

	/*border=generatelSegmentedImage(lbpImg.size(),regions);

	cv::imshow("border",border);
	cv::waitKey(0);
*/
}


void merge(std::vector<Region>& regions, float miTh, unsigned minIters,float sTh){

	float ratioSalida;
	int currIter=0;
	float MI_cur=0,MI_max=0,MI_min;
	std::vector<std::vector<Adyacentes>> Adyacent;
	bool adyacentBoolean=false;
	bool salir=false;

	int itI, itJ;

	Adyacent.resize(regions.size());
	for(int i=0;i<regions.size();i++){
		Adyacent[i].resize(regions.size());
	}

	for(int i=0;i<regions.size();i++){	
		for(int j=i+1;j<regions.size();j++){
			Adyacent[i][j].dist=0;
			Adyacent[i][j].active=true;

		}
	}

//Genera matriz adyacencias, facilita el trabajo posterior
	for(int i=0;i<regions.size();i++){
		for(int j=i+1;j<regions.size();j++){
			adyacentBoolean=regions[i].areAdjacents(regions[j]);
			if(adyacentBoolean){
				//std::cout<<"i: "<<i<<" j: "<<j<<std::endl;
				Adyacent[i][j].dist=computeMICoeff(regions[i],regions[j]);

			}
			adyacentBoolean=false;
		}
	}
//Busqueda de adyacencias
	MI_max=999999999;
	std::vector<Region>::iterator it;
	do{

		itI=-1;
		itJ=-1;
		MI_max;
		MI_cur=0;
		MI_min=9999999;
		currIter++;
		//Busqueda de minimo valor MI
		for(int i=0;i<regions.size();i++){
			for(int j=i+1;j<regions.size();j++){
				if(Adyacent[i][j].active){
					MI_cur=Adyacent[i][j].dist;
				}
				if(MI_min>MI_cur and MI_cur!=0){
						itI=i;
						itJ=j;
						MI_min=MI_cur;
				}
			}
		}
		
		//std::cout<<"itI: "<<itI<<" itJ: "<<itJ<<std::endl;
		if(itI==-1 or itJ==-1){
			salir=true;
		}else{
			if(esHomogenea(regions[itI],regions[itJ],sTh)){//Son homogeneas
				MI_cur=MI_min;
				//if(MI_cur>MI_max){
				//	MI_max=MI_cur;
				//}
				regions[itI].merge(regions[itJ]);
				int x;
				for(it=regions.begin(),x=0;it!=regions.end();x++,it++){
					if(x==itJ){
						regions.erase(it);
						break;
					}
				}
				for(int k=0;k<regions.size();k++){
					Adyacent[k][itJ].active=false;
					Adyacent[itJ][k].active=false;
				}
				for(int k=0;k<regions.size();k++){
					if(k!=itI and k!=itJ){
						Adyacent[itI][k].dist=computeMICoeff(regions[itI],regions[k]);
						Adyacent[k][itI].dist=Adyacent[itI][k].dist;
					}
				}
			}else{
				salir=true;
			}
		ratioSalida=MI_cur/MI_max;

//		std::cout<<"itI: "<<itI<<" itJ: "<<itJ<<std::endl;
		//std::cout<<"MI_cur: "<<MI_cur<<" MI_max: "<<MI_max<<" MI_min: "<<MI_min<<std::endl;
		//std::cout<<"ratioSalida: "<<ratioSalida<<" Curr iter: "<<currIter<<std::endl<<std::endl;

		MI_max=MI_cur;
		}
		


	}while((ratioSalida<=miTh or minIters>currIter) and !salir);

}


bool esHomogenea(const Region& r1, const Region& r2,float sTh){
	float dist=computeHistogramDistance(r1.hist(),r2.hist());
	//std::cout<<"dist: "<<dist<<std::endl; 
	if(dist>sTh){//No son homogeneas
		return false;
	}else{
		return true;
	}
}

//void refine(const cv::Mat& lbpImg, cv::Mat& segImage, float radius, unsigned maxIters);



int tablaCodigoUniforme(int valorLBP){
	int valorLBPUniformed=-1;
	switch(valorLBP){//Los case son el resultado de evaluar el valor del vector de los patrones aceptados
			case 0:

				valorLBPUniformed=0;
				break;
			case 16:

				valorLBPUniformed=1;
				break;
			
			case 8:

				valorLBPUniformed=2;
				break;
			
			case 4:

				valorLBPUniformed=3;
				break;
			
			case 2:

				valorLBPUniformed=4;
				break;
			
			case 1:

				valorLBPUniformed=5;
				break;
			
			case 128:

				valorLBPUniformed=6;
				break;
			
			case 64:

				valorLBPUniformed=7;
				break;
			
			case 32:

				valorLBPUniformed=8;
				break;
			
			case 24:

				valorLBPUniformed=9;
				break;
			
			case 12:

				valorLBPUniformed=10;
				break;
			
			case 6:

				valorLBPUniformed=11;
				break;
			
			case 3:

				valorLBPUniformed=12;
				break;
			
			case 129:

				valorLBPUniformed=13;
				break;
			
			case 192:

				valorLBPUniformed=14;
				break;
			
			case 96:

				valorLBPUniformed=15;
				break;
			
			case 48:

				valorLBPUniformed=16;
				break;
			
			case 56:

				valorLBPUniformed=17;
				break;
			
			case 28:

				valorLBPUniformed=18;
				break;
			
			case 14:

				valorLBPUniformed=19;
				break;
			
			case 7:

				valorLBPUniformed=20;
				break;
			
			case 131:

				valorLBPUniformed=21;
				break;
			
			case 193:

				valorLBPUniformed=22;
				break;
			
			case 224:

				valorLBPUniformed=23;
				break;
			
			case 112:

				valorLBPUniformed=24;
				break;
			
			case 60:

				valorLBPUniformed=25;
				break;
			
			case 30:

				valorLBPUniformed=26;
				break;
			
			case 15:

				valorLBPUniformed=27;
				break;
			
			case 135:

				valorLBPUniformed=28;
				break;
			
			case 195:

				valorLBPUniformed=29;
				break;
			
			case 225:

				valorLBPUniformed=30;
				break;
			
			case 240:

				valorLBPUniformed=31;
				break;
			
			case 120:

				valorLBPUniformed=32;
				break;
			
			case 124:

				valorLBPUniformed=33;
				break;
			
			case 62:

				valorLBPUniformed=34;
				break;
			
			case 31:

				valorLBPUniformed=35;
				break;
			
			case 143:

				valorLBPUniformed=36;
				break;
			
			case 199:

				valorLBPUniformed=37;
				break;
			
			case 227:

				valorLBPUniformed=38;
				break;
			
			case 241:

				valorLBPUniformed=39;
				break;
			
			case 248:

				valorLBPUniformed=40;
				break;
			
			case 126:

				valorLBPUniformed=41;
				break;
			
			case 63:

				valorLBPUniformed=42;
				break;
			
			case 159:

				valorLBPUniformed=43;
				break;
			
			case 207:

				valorLBPUniformed=44;
				break;
			
			case 231:

				valorLBPUniformed=45;
				break;
			
			case 243:

				valorLBPUniformed=46;
				break;
			
			case 249:

				valorLBPUniformed=47;
				break;
			
			case 252:

				valorLBPUniformed=48;
				break;
			
			case 254:

				valorLBPUniformed=49;
				break;
			
			case 127:

				valorLBPUniformed=50;
				break;
			
			case 191:

				valorLBPUniformed=51;
				break;
			
			case 223:

				valorLBPUniformed=52;
				break;
			
			case 239:

				valorLBPUniformed=53;
				break;
			
			case 247:

				valorLBPUniformed=54;
				break;
			
			case 251:

				valorLBPUniformed=55;
				break;
			
			case 253:

				valorLBPUniformed=56;
				break;
			
			case 255:

				valorLBPUniformed=57;
				break;
			
			default:

				valorLBPUniformed=58;
				break;
			
			

		}
		return valorLBPUniformed;
}