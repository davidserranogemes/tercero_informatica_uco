Los ficheros de código que se piden se encuentran dentro de la carpeta código.

Los ejemplos realizados (test) se encuentran dentro de la carpeta codigo/test. Esta carpeta contiene tambíen los ejemplos planteados por el profesor.